<html>
<?php

$nom= "Bienvenue sur mon Blog !";
echo $nom

 ?>
<body> 
<h1> MIHOUBI Ilias </h1> 

<h2> Blog Volkswagen</h2>
<img src = "vw.png" alt = "Logo">


</body>
<p> Bienvenue sur mon blog, je vais vous présenter l'une des meilleurs marques de voitures allemandes à très bon prix pour jeune conducteur ! </p>







<footer> Crée le 03 mai 2023 à 14h00 </footer>



</html>