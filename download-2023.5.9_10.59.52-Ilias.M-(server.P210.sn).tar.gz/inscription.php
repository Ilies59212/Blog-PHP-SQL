<html>
    <!-- Inclusion du fichier configuration.php -->
    <?php include("configuration.php"); ?>

    <!--code HTML classique -->
    <head>
        <title> Inscription dans la table utilisateurs </title>
    </head>

    <body>
        <?php
        if(!empty($_POST))
        {
                $userPHP = $_POST['userHTML'];
                $mdpPHP = $_POST['mdpHTML'];
          if($user && $mdp)
                {
                    $requete = "INSERT INTO utilisateurs VALUES(NULL,'$userPHP','$mdpPHP')";
                    echo "voici votre requete :".$requete;
                    $exec = $connect -> prepare($requete);
            $exec -> execute();
            echo "<h4> Inscription bien exffectuée</h4>";
                }
          else
            {
            echo "<h2> Attention il maque login ou mot de passe</h2>";
            }
        }
        else
        {
        ?>
            <center>
                <h1> INSCRIPTION dans la table users</h1>
                <form action="inscription.php" method="POST">
                    <label >Votre Nom :</label>
                    <input type="text" name="userHTML"/></input><br/>

                    <label> Votre Mot de passe :</label>
                    <input type="password" name="mdpHTML" /></input>

                    <input type="submit"/>
                </form>
            </center>
        <?php
        }
        ?>
</body>
</html>