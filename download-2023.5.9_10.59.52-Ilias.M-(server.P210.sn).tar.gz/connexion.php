<html>
    <!-- Inclusion du fichier configuration.php -->
    <?php include("configuration.php"); ?>

    <!--code HTML classique -->
    <head>
        <title> Vérification login & mot de pass</title>
    </head>

<body>
    <center>
        <h1> Se connecter avec login et mot de passe </h1>
        <!-- Formulaire de saisie de login et mdp -->
        <!-- Utilisation de la méthode POST vers connexion.php -->
        <form action="connexion.php" method="POST">
            <label >Votre Nom :</label>
            <input type="text" name="userHTML"/></input><br/>

            <label> Votre Mot de passe :</label>
            <input type="password" name="mdpHTML" /></input>

            <input type="submit" value="Envoyer le formulaire"/>
         </form>
     </center>    
     <?php
        //récupération des variables PHP via la méthode POST//
        $userPHP = $_POST['userHTML'];
        $mdpPHP = $_POST['mdpHTML'];
        
        //Vérification que les deux champs soient remplit//
        if($userPHP && $mdpPHP)
        {
            //requete pour récuperer le mot de passe correspondant au login saisie//
            $requete = 'SELECT password FROM utilisateurs WHERE login="'.$userPHP.'"';
            $exec = $connect -> prepare($requete);
            $exec -> execute();
            //FETCH_ASSOC Retourne un tableau indexé par le nom des colonnes
            $dataRetour = $exec -> fetch(PDO::FETCH_ASSOC);
            //Test si le mot de passe est OK//
            if ($dataRetour['password']==$mdpPHP)
                { echo "<h1>Bienvenue sur la page avec connexion via MDP et Login</h1>"; }
            //Test si le mot de passe n'est pas le bon//
            else
                { echo "<h1>Votre login ou mdp ne sont pas valides</h1>"; }
        }
        //Si un champ est vide//
        else
            { echo "<h1>il manque login ou mot de passe</h1>"; }
        ?>
</body>
</html>