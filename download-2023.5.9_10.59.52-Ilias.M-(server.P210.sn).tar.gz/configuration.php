<?php

//Déclaration des variables PHP avec le $
$host="localhost";
$user="user_moi";
$mdp="password";
$bdd="ma_base_de_donnee";

//récupération des paramètres de configuration dans la variable PHP connect
$connect = new PDO('mysql:host='.$host.';dbname='.$bdd.';charset=utf8',$user,$mdp);

//fin du code PHP
?>